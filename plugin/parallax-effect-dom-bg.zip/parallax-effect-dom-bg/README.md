# jQParralax
Simple jQuery parallax effect over background images

Sample on JSFiddle: https://jsfiddle.net/howbizarre/qhet04d2/
